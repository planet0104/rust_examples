use std::{time::Duration, sync::{RwLock, Arc}, io::Cursor};

use fast_qr::{QRBuilder, convert::svg::SvgBuilder};
use nokhwa::{utils::{CameraIndex, RequestedFormat, RequestedFormatType, Resolution}, pixel_format::RgbAFormat, Camera};
use slint::{Weak, SharedPixelBuffer, Image, SharedString};
use anyhow::{Result, anyhow};
use crate::alert;

use super::ui::App;

const BEEP_MP3:&[u8] = include_bytes!("../beep.mp3");

// 启动相机
pub fn start(app_weak: Weak<App>) -> Result<()>{

    let cfg = crate::config::read_config();

    //测试摄像头是否打开成功
    let camera = open_camera(cfg.camera_index, Resolution { width_x: cfg.camera_width, height_y: cfg.camera_height })?;
    drop(camera);

    //线程中启动15帧左右的摄像头
    std::thread::spawn(move ||{
        let app_clone = app_weak.clone();
        if let Err(err) = start_loop(app_weak, cfg.camera_index, Resolution { width_x: cfg.camera_width, height_y: cfg.camera_height }){
            app_clone.upgrade().unwrap().set_camera_opened(false);
            alert(&format!("相机已关闭:{:?}", err));
        }
    });
    Ok(())
}

// 打开摄像头
fn open_camera(index: u32, resolution: Resolution) -> Result<Camera>{
    let index = CameraIndex::Index(index);
    let requested = RequestedFormat::new::<RgbAFormat>(RequestedFormatType::HighestResolution(resolution));
    let camera = Camera::new(index, requested)?;
    Ok(camera)
}

// 启动摄像头拍照线程
fn start_loop(app_weak: Weak<App>, camera_index: u32, resolution: Resolution) -> Result<()>{
    let mut camera = open_camera(camera_index, resolution)?;
    let opened = Arc::new(RwLock::new(true));

    let decoder = bardecoder::default_decoder();
    let mut last_scan_code = String::new();
    let mut last_qrcode_svg: Option<String> = None;
    loop{
        
        if let Ok(opened) = opened.read(){
            if !*opened{
                break;
            }
        }

        let frame = camera.frame()?;
        let decoded = frame.decode_image::<RgbAFormat>()?;

        //扫描二维码
        if let Some(Ok(scan_result)) = decoder.decode(&decoded).iter().next(){
            if last_scan_code == *scan_result{

            }else{
                last_scan_code = scan_result.to_string();
                println!("扫描结果:{last_scan_code}");
                //生成二维码图片
                let qr = QRBuilder::new(scan_result.as_bytes()).build()?;
                let svg = SvgBuilder::default().to_str(&qr);
                last_qrcode_svg = Some(svg);
                beep();
            }
        }

        let shared = SharedPixelBuffer::clone_from_slice(&decoded, decoded.width(), decoded.height());
        let opened_clone: Arc<RwLock<bool>> = opened.clone();
        let last_scan_code_clone = last_scan_code.clone();
        let last_qrcode_svg_clone = last_qrcode_svg.clone();
        app_weak.upgrade_in_event_loop(move |app| {
            if let Ok(mut opened) = opened_clone.try_write(){
                *opened = app.get_camera_opened();
            }
            let old_device_qrcode = app.get_device_qrcode();
            if let Some(svg) = last_qrcode_svg_clone{
                let qrcode_image = Image::load_from_svg_data(svg.as_bytes()).unwrap();
                app.set_qrcode_image(qrcode_image);
            }
            if last_scan_code_clone != old_device_qrcode.as_str(){
                app.set_device_qrcode(SharedString::from(last_scan_code_clone));
            }
            app.set_video_frame(Image::from_rgba8(shared))
        }).map_err(|err| anyhow!("{:?}", err))?;
       
        std::thread::sleep(Duration::from_millis(66));
    }
    Ok(())
}

pub fn beep(){
    std::thread::spawn(||{
        let (_stream, handle) = rodio::OutputStream::try_default().unwrap();
        let sink = rodio::Sink::try_new(&handle).unwrap();
        let cursor = Cursor::new(BEEP_MP3);
        sink.append(rodio::Decoder::new(cursor).unwrap());
        sink.sleep_until_end();
    });
}