use anyhow::Result;
use serde::{Deserialize, Serialize};
use slint::{Weak, Model, VecModel, SharedString};
use std::{fs::File, io::{Read, Write}};
use crate::App;

pub const CFG_FILE:&str = "蓝牙装备注册.toml";

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Config {
    //相机编号
    pub camera_index: u32,
    //相机预览width
    pub camera_width: u32,
    //相机预览height
    pub camera_height: u32,
    //串口名称
    pub serial_name: String,
    //波特率
    pub baud_rate: u32,
}

impl Default for Config{
    fn default() -> Self {
        Self {camera_index: Default::default(), camera_width: 1280, camera_height: 720, serial_name: "".to_string(), baud_rate: 115200 }
    }
}

// 读取配置
pub fn read_config() -> Config {
    let read_cfg = || -> Result<Config>{
        let mut config_file = File::open(CFG_FILE)?;
        let mut config_str = String::new();
        config_file.read_to_string(&mut config_str)?;
        Ok(toml::from_str(&config_str)?)
    };
    match read_cfg(){
        Ok(cfg) => cfg,
        Err(_err) => Config::default()
    }
}

pub fn save_config(cfg: &Config) -> Result<()> {
    let mut config_file = File::create(CFG_FILE)?;
    let cfg_str = toml::to_string(cfg)?;
    config_file.write_all(cfg_str.as_bytes())?;
    Ok(())
}

pub fn save_config_async(app: Weak<App>){
    let app = app.unwrap();
    let serial_name  = app.get_serial_name();
    let camera_index = app.get_camera_index();
    let camera_size_index = app.get_camera_size_index();
    let camera_size_list = app.get_camera_size_list();
    let resolutions = camera_size_list.as_any().downcast_ref::<VecModel<SharedString>>().unwrap();
    let mut camera_width = 1280;
    let mut camera_height = 720;
    if let Some((_, resolution)) = resolutions.iter().enumerate().find(|v| v.0 == camera_size_index as usize){
        let arr = resolution.replace("分辨率:", "");
        let arr:Vec<&str> = arr.split("x").collect();
        camera_width = arr[0].parse().unwrap();
        camera_height = arr[1].parse().unwrap();
    }

    std::thread::spawn(move ||{
        let mut cfg = read_config();
        cfg.serial_name = serial_name.to_string();
        cfg.camera_index = camera_index as u32;
        cfg.camera_width = camera_width;
        cfg.camera_height = camera_height;
        save_config(&cfg).unwrap();
        println!("保存了配置:{:?}", cfg);
    });
}