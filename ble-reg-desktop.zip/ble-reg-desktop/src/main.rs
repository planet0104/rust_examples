use anyhow::Result;
mod ui;
mod config;
mod serial;
mod camera;
mod server_api;
use config::save_config_async;
use rfd::MessageDialog;
use serial::{update_ui_serial_ports, listen_serial_port};
use ui::App;
use slint::{ComponentHandle, SharedString, Model, VecModel};

fn main() -> Result<()> {
    
    let app = App::new()?;

    //读取配置文件
    let cfg = config::read_config();
    app.set_serial_name(SharedString::from(cfg.serial_name));
    app.set_camera_index(cfg.camera_index as i32);
    let camera_size_list = app.get_camera_size_list();
    let resolutions = camera_size_list.as_any().downcast_ref::<VecModel<SharedString>>().unwrap();
    if let Some((idx, _)) = resolutions.iter().enumerate().find(|v| v.1.contains(&format!("{}x{}", cfg.camera_width, cfg.camera_height))){
        app.set_camera_size_index(idx as i32);
    }

    //相机
    let app_weak = app.as_weak();
    app.on_open_camera(move ||{
        if let Err(err) = camera::start(app_weak.clone()){
            app_weak.unwrap().set_camera_opened(false);
            alert(&format!("相机打开失败:{:?}", err))
        }
    });

    // 串口
    let app_weak = app.as_weak();
    app.on_list_serial(move|| update_ui_serial_ports(app_weak.clone()).unwrap() );

    //线程: 串口自动重连; 设备信息读取;
    listen_serial_port(app.as_weak(), vec![
        "AT+NAME?\r\n".as_bytes().to_vec(),
        "AT+COLOR?\r\n".as_bytes().to_vec(),
        "AT+MAC?\r\n".as_bytes().to_vec(),
    ]);

    //刷新串口列表
    update_ui_serial_ports(app.as_weak()).unwrap();

    //接收串口消息
    let message_callback = move |app, message|{
        println!("串口信息:{:?}", message);
    };

    let app_weak = app.as_weak();
    app.on_open_serial(move ||{
        let app = app_weak.clone();
        app_weak.unwrap().set_serial_opened(true);
        if let Err(err) = serial::open(app, message_callback){
            app_weak.unwrap().set_serial_opened(false);
            alert(&format!("串口打开失败:{:?}", err))
        }
    });

    //修改了摄像头、串口参数后，保存配置文件
    let app_weak = app.as_weak();
    app.on_save_config(move || save_config_async(app_weak.clone()));

    app.run()?;

    Ok(())
}

pub fn alert(msg: &str){
    let _ = MessageDialog::new()
    .set_title("提示")
    .set_description(msg)
    .show();
}
