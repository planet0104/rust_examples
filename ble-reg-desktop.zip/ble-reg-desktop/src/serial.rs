use std::{rc::Rc, sync::{Arc, RwLock, mpsc::{channel, Sender, Receiver}, Mutex}, io::{self, Read, Write}, thread, time::Duration};

use anyhow::{anyhow, Result};
use mio::{Poll, Events, Interest, Token, Waker};
use mio_serial::SerialPortBuilderExt;
use once_cell::sync::Lazy;
use serialport::SerialPortInfo;
use slint::{Weak, SharedString, ModelRc, VecModel};
use chrono::prelude::*;
use crate::{App, alert};

const SERIAL_TOKEN: Token = Token(0);
const WAKE_TOKEN: Token = Token(10);

// 串口发送器 全局变量， 串口链接成功后设置， 串口监听线程中获取它
static SERIAL_SENDER: Lazy<Mutex<Option<Sender<Vec<u8>>>>> = Lazy::new(|| Mutex::new(None) );
static SERIAL_LOGS: Lazy<Mutex<Vec<String>>> = Lazy::new(|| Mutex::new(vec![]) );

/// 查找所有串口信息
pub fn list_serial_ports() -> Result<Vec<SerialPortInfo>> {
    Ok(serialport::available_ports()?)
}

// 添加一条串口日志, 并更新到UI中
fn append_log(app:Weak<App>, data:Vec<u8>, send: bool){
    let mut logs = match SERIAL_LOGS.lock().map_err(|err| anyhow!("{:?}", err)){
        Ok(v) => v,
        Err(_) => return
    };
    let local: DateTime<Local> = Local::now();
    let formatted = local.format("%Y-%m-%d %H:%M:%S").to_string();
    let tag = if send{
        "发送"
    }else{
        "接收"
    };
    let log = match String::from_utf8(data){
        Ok(v) => v,
        Err(_) => return
    };
    logs.insert(0, format!("[{formatted} {tag}]:{log}"));
    if logs.len() > 1000{
        let _ = logs.pop();
    }

    //在UI中更新串口列表
    let serial_logs_str = SharedString::from(logs.join(""));
    let _ = app.upgrade_in_event_loop(move |app|{
        //更新串口日志
        app.set_serial_logs(serial_logs_str);
    });
}

// 监听串口链接状态，断开连接后自动重连 / 定时发送消息
pub fn listen_serial_port(app_weak: Weak<App>, commands: Vec<Vec<u8>>){
    std::thread::spawn(move ||{
        //缓存日志信息
        loop{
            std::thread::sleep(Duration::from_secs(1));
            
            //发送串口命令
            for cmd in &commands{
                let _ = write_data(cmd.clone());
                std::thread::sleep(Duration::from_millis(50));
            }

            let _ = app_weak.upgrade_in_event_loop(move |app|{
                let opened = app.get_serial_opened();
                if !opened{
                    app.invoke_open_serial();
                }
            });
        }
    });
}

// 更新ui串口列表
pub fn update_ui_serial_ports(app_weak: Weak<App>) -> Result<()>{
    std::thread::spawn(move ||{
        match list_serial_ports(){
            Ok(list) => {
                let list:Vec<SharedString> = list.iter().map(|v| {
                    v.port_name.clone().into()
                }).collect();
                let _ = app_weak.upgrade_in_event_loop(move |app| {
                    if list.len() > 0{
                        app.set_serial_name(list[0].clone());
                    }else{
                        app.set_serial_name(SharedString::from(""));
                    }
                    let model : Rc<VecModel<SharedString>> =
                            Rc::new(VecModel::from(list));
                    let rc = ModelRc::from(model);

                    app.set_serial_name_list(rc);
                });
            }
            Err(err) => {
                alert(&format!("查询查询失败:{:?}", err))
            }
        }
    });
    Ok(())
}

// 启动串口
pub fn open(app_weak: Weak<App>, message_callback: fn(App, Vec<u8>)) -> Result<()>{
    let app_clone = app_weak.clone();
    let app = app_weak.upgrade().unwrap();
    let baud_rate = app.get_baud_rate() as u32;
    let serial_name:String = app.get_serial_name().into();
    let (sender, receiver) = channel();
    SERIAL_SENDER.lock().map_err(|err| anyhow!("{:?}", err))?.replace(sender);
    std::thread::spawn(move ||{
        let app_weak = app_clone.clone();
        if let Err(err) = start_loop(app_weak, baud_rate, serial_name, receiver, message_callback){
            println!("串口出错:{:?}", err);
            if let Ok(mut s) = SERIAL_SENDER.lock(){
                let _ = s.take();
            }
            app_clone.upgrade_in_event_loop(move |app|{
                app.set_serial_opened(false);
                // alert(&format!("串口已关闭:{:?}", err));
            }).unwrap();
        }
    });

    Ok(())
}

// 发送数据
pub fn write_data(data: Vec<u8>) -> Result<()>{
    let sender = SERIAL_SENDER.lock().map_err(|err| anyhow!("{:?}", err))?;
    if sender.is_none(){
        return Err(anyhow!("串口未打开!"))
    }
    sender.as_ref().unwrap().send(data).map_err(|err| anyhow!("{:?}", err))?;
    Ok(())
}

// 启动串口接收线程
fn start_loop(app_weak: Weak<App>, baud_rate:u32, serial_name: String, receiver: Receiver<Vec<u8>>, message_callback: fn(App, Vec<u8>)) -> Result<()>{
    
    // Create a poll instance.
    let mut poll = Poll::new()?;
    // Create storage for events. Since we will only register a single serialport, a
    // capacity of 1 will do.
    let mut events = Events::with_capacity(1);

    // Create the serial port
    println!("打开串口 {} at {},8N1", serial_name, baud_rate);
    let mut rx = mio_serial::new(serial_name, baud_rate).open_native_async()?;
    println!("串口打开成功");
    
    poll.registry()
        .register(&mut rx, SERIAL_TOKEN, Interest::READABLE)?;

    let opened = Arc::new(RwLock::new(true));

    let waker = Waker::new(poll.registry(), WAKE_TOKEN)?;

    let opened_clone = opened.clone();
    // 我们需要让 Waker 保持活动状态，因此我们将为我们在下面创建的线程创建一个克隆。
    let _handle = thread::spawn(move || {
        loop{
            if let Ok(opened) = opened_clone.try_read() {
                if !*opened {
                    eprintln!("串口已关闭 Poll唤醒线程退出.");
                    break;
                }
            }
            thread::sleep(Duration::from_millis(10));
            if let Err(err) = waker.wake(){
                eprintln!("Poll唤醒失败 {:?}", err);
                break;
            }
        }
        eprintln!("Poll唤醒线程结束.");
    });

    let mut buf = [0u8; 1024];
    
    let mut timer_count = 0u64;
    loop {
        timer_count += 1;
        if let Ok(opened) = opened.read(){
            if !*opened{
                break;
            }
        }
        
        //接收要发送的数据
        if let Ok(data) = receiver.try_recv(){
            if let Err(err) = rx.write_all(&data) {
                eprintln!("串口写入失败: {:?}", err);
            } else {
                std::thread::sleep(Duration::from_millis((1000.0 / (baud_rate as f32)) as u64));
                // append_log(app_weak.clone(), data, true);
            }
        }
        
        if timer_count%5==0{
            let opened_clone = opened.clone();
            app_weak.upgrade_in_event_loop(move |app| {
                if let Ok(mut opened) = opened_clone.try_write(){
                    *opened = app.get_serial_opened();
                }
            }).map_err(|err| anyhow!("{:?}", err))?;
        }

        // Poll to check if we have events waiting for us.
        poll.poll(&mut events, None)?;

        // Process each event.
        for event in events.iter() {
            // Validate the token we registered our socket with,
            // in this example it will only ever be one but we
            // make sure it's valid none the less.
            match event.token() {
                SERIAL_TOKEN => loop {
                    // In this loop we receive all packets queued for the socket.
                    match rx.read(&mut buf) {
                        Ok(count) => {
                            //发送到UI线程处理
                            let data = buf[..count].to_vec();
                            append_log(app_weak.clone(), data.clone(), false);
                            let _ = app_weak.upgrade_in_event_loop(move |app|{
                                message_callback(app, data);
                            });
                        }
                        Err(ref e) if e.kind() == io::ErrorKind::WouldBlock => {
                            break;
                        }
                        Err(e) => {
                            println!("Quitting due to read error: {}", e);
                            return Err(anyhow!("{:?}", e));
                        }
                    }
                },
                _ => {
                    // This should never happen as we only registered our
                    // `UdpSocket` using the `UDP_SOCKET` token, but if it ever
                    // does we'll log it.
                    // warn!("Got event for unexpected token: {:?}", event);
                }
            }
        }
    }
    println!("串口线程结束..");
    Ok(())
}