use reqwest::{Client, header};
use serde::Deserialize;
use anyhow::Result;

#[derive(Clone, Debug, Deserialize)]
pub struct ApiResponse<T> {
    pub return_code: i32,
    pub success: bool,
    pub msg: String,
    pub data: T,
}

#[derive(Deserialize, Clone, Debug)]
pub struct PiupiuDevice {
    pub id: i32,
    #[serde(rename = "type")]
    pub _type: i32,
    #[serde(rename = "subType")]
    pub sub_type: i32,
    pub qrcode: String,
    #[serde(rename = "deviceName")]
    pub device_name: String,
    pub code: String,
    pub uuid: String,
    #[serde(rename = "macAddress")]
    pub mac_address: String
}

fn new_http_client(token: Option<&str>) -> Result<Client>{
    let mut headers = header::HeaderMap::new();
    headers.insert("name", header::HeaderValue::from_static("piupiu2023"));
    headers.insert("TOKEN", header::HeaderValue::from_static("GLSA_TEST_REG_123456"));
    if let Some(token) = token{
        headers.insert("TOKEN", header::HeaderValue::from_str(token).unwrap());
    }

    Ok(Client::builder()
    .default_headers(headers)
    .build()?)
}

/// 注册装备
/// * `url` 服务器地址
/// * `code` 蓝牙的MAC地址
/// * `type` 1：枪 2：头盔 3：胸甲 4：裤
/// * `sub_type` 子类型
/// * `colour` 颜色
pub async fn reg_piupiu_device(url:&str, code:&str, _type:i32, sub_type: i32, color: i32) -> Result<ApiResponse<PiupiuDevice>>{
    let url = format!("{}/piupiuDevice/reg?code={code}&type={_type}&sub_type={sub_type}&color={color}", url);
    println!("注册装备:{url}");
    let resp = new_http_client(None)?.get(url).send().await?.text().await?;
    println!("注册装备返回:{resp}");
    Ok(serde_json::from_str(&resp)?)
}

/// 查询装备
/// * `url` 服务器地址
/// * `code` 蓝牙的MAC地址
pub async fn query_piupiu_device(url:&str, code:&str) -> Result<ApiResponse<Vec<PiupiuDevice>>>{
    let url = format!("{}/piupiuDevice/selectByModel?code={code}", url);
    println!("注册装备:{url}");
    let resp = new_http_client(None)?.get(url).send().await?.text().await?;
    println!("注册装备返回:{resp}");
    Ok(serde_json::from_str(&resp)?)
}

