
slint::slint!{
    import { Button , HorizontalBox, VerticalBox, ComboBox, GridBox, Switch, TextEdit} from "std-widgets.slint";
    export component App inherits Window {
        title: "蓝牙装备注册";
        width: 1000px;
        height: 600px;
        icon: @image-url("logo.png");

        callback open-camera();
        callback list-serial();
        callback open-serial();
        callback save-config();
        
        in-out property <int> camera-index: 0;
        property <[string]> camera-index-list: ["相机编号:0", "相机编号:1", "相机编号:2", "相机编号:3", "相机编号:4"];

        in-out property <[string]> camera-size-list: ["分辨率:1280x720", "分辨率:960x540", "分辨率:640x480"];
        in-out property <int> camera-size-index: 0;

        in-out property <string> qrcode-device-name: "请扫描二维码";
        in-out property <string> device_qrcode: "将设备二维码放入摄像头区域";
        in-out property <image> qrcode_image;
        
        in-out property <bool> camera-opened: false;
        in-out property <int> camera-width: 1280;
        in-out property <int> camera-height: 720;
        in property <image> video-frame <=> image.source;

        in-out property <bool> serial-opened: false;
        in-out property <[string]> serial-name-list: [];
        in-out property <string> serial-name: "";
        in-out property <int> baud-rate: 115200;
        //上次串口读取时间
        in property <string> serial-read-time: "00:00:00";
        //蓝牙设备读取到的名称
        in property <string> serial-device-name: "";
        //蓝牙设备MAC
        in property <string> serial-device-mac: "";
        //串口读到的装备颜色
        in property <color> serial-device-color: transparent;
        // 自动读取串口装备信息
        in-out property <bool> auto-read: true;
        //串口日志
        in property <string> serial-logs: "";

        //选中的注册颜色
        in-out property <color> register-color: black;
        //注册颜色列表
        in-out property <[string]> color-name-list: ["曜石黑", "皓月白", "粉晶色", "蒂芙尼蓝", "中国红"];
        //是否正在注册中
        in-out property <bool> registering: false;

        //手动触发打开串口事件
        function invoke_open_serial() {
            if(!serial-opened){
                serial-opened = true;
                open-serial()
            }
        }
        
        VerticalBox {
            HorizontalLayout {
                Rectangle {
                    width: 500px;
                    height: 300px;
                    image := Image {
                        max-width: 500px;
                        preferred-width: 500px;
                        height: 300px;
                    }
                }
                VerticalBox {
                    width: 500px;
                    alignment: center;
                    Rectangle {
                        width: 500px;
                        height: 250px;
                        Image {
                            max-width: 500px;
                            preferred-width: 500px;
                            height: 250px;
                            source: qrcode-image;
                        }
                    }
                    Text {
                        width: 100%;
                        horizontal-alignment: center;
                        font-size: 16px;
                        color: green;
                        text: "扫描结果:"+device_qrcode;
                    }
                }
            }
            HorizontalBox {
                width: 100%;
                height: 200px;
                Rectangle {
                    width: 45%;
                    height: 200px;
                    border-radius: 3px;
                    border-color: #cce;
                    border-width: 1px;
                    VerticalBox {
                        Text {
                            font-weight: 600;
                            color: gray;
                            text: "串口日志"+" [端口"+serial-name+(serial-opened?"已打开":"未打开")+"]";
                        }
                        TextEdit {
                            text: serial-logs;
                        }
                    }
                }
                Rectangle {
                    width: 53%;
                    height: 200px;
                    border-radius: 3px;
                    border-color: #ccc;
                    border-width: 1px;
                    HorizontalLayout {
                        Rectangle {
                            width: 50%;
                            VerticalBox {
                                Text {
                                    height: 20px;
                                    font-weight: 600;
                                    color: gray;
                                    text: "当前装备信息";
                                }
                                VerticalBox {
                                    Rectangle {
                                        background: #222;
                                        VerticalBox {
                                            Text { text: "蓝牙名称："+serial-device-name; }
                                            HorizontalLayout {
                                                Text { vertical-alignment: center; text: "装备颜色:"; }
                                                Rectangle { width: 15px; }
                                                Rectangle {
                                                    width: 40px;
                                                    height: 40px;
                                                    border-radius: 4px;
                                                    background: serial-device-color;
                                                }
                                            }
                                            Text { text: "MAC:"+serial-device-mac; }
                                        }
                                    }
                                }
                                HorizontalBox {
                                    alignment: start;
                                    // Button {
                                    //     enabled: !auto-read;
                                    //     text: "读取装备";
                                    //     width: 80px;
                                    //     height: 30px;
                                    //     clicked => {
                                    //         list-serial()
                                    //     }
                                    // }
                                    Text {
                                        color: gray;
                                        text: "上次读取时间: "+serial-read-time;
                                    }
                                }
                            }
                        }
                        Rectangle { width: 1px; y:20px; height: 160px; background: #ddd; }
                        Rectangle {
                            VerticalBox {
                                Text {
                                    height: 20px;
                                    font-weight: 600;
                                    color: gray;
                                    text: "注册装备";
                                }
                                VerticalBox {
                                    HorizontalLayout {
                                        ComboBox {
                                            model: color-name-list;
                                            selected(value) => {
                                                if(value == "曜石黑"){
                                                    register-color = rgba(0,0,0,1);
                                                }else if(value == "皓月白"){
                                                    register-color = rgba(255,255,255,1);
                                                }else if(value == "粉晶色"){
                                                    register-color = rgba(255, 192, 203, 1);
                                                }else if(value == "蒂芙尼蓝"){
                                                    register-color = rgba(0, 183, 183, 1);
                                                }else{
                                                    register-color = rgba(227, 23, 13, 1);
                                                }
                                            }
                                        }
                                        Rectangle { width: 15px; }
                                        Rectangle {
                                            width: 40px;
                                            height: 40px;
                                            border-radius: 4px;
                                            background: register-color;
                                        }
                                    }
                                    Text {
                                        vertical-alignment: center;
                                        font-size: 14px;
                                        text: "蓝牙名称："+qrcode-device-name;
                                    }
                                    Button {
                                        enabled: !registering;
                                        text: "注册并写入装备";
                                        height: 40px;
                                        clicked => {
                                            registering = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            VerticalBox {
                alignment: end;
                HorizontalBox {
                        alignment: center;
                        ComboBox {
                            width: 120px;
                            height: 40px;
                            model: camera-index-list;
                            current-value: camera-index-list[camera-index];
                            selected(value) => {
                                if(value == camera-index-list[0]){
                                    camera-index = 0;
                                }else if(value == camera-index-list[1]){
                                    camera-index = 1;
                                }else if(value == camera-index-list[2]){
                                    camera-index = 2;
                                }else if(value == camera-index-list[3]){
                                    camera-index = 3;
                                }else if(value == camera-index-list[4]){
                                    camera-index = 4;
                                }
                                save-config()
                            }
                        }
                        ComboBox {
                            width: 140px;
                            height: 40px;
                            model: camera-size-list;
                            current-value: camera-size-list[camera-size-index];
                            selected(value) => {
                                if(value == camera-size-list[0]){
                                    camera-size-index = 0;
                                    camera-width = 1280;
                                    camera-height = 720;
                                }else if(value == camera-size-list[1]){
                                    camera-size-index = 1;
                                    camera-width = 960;
                                    camera-height = 540;
                                }else if(value == camera-size-list[2]){
                                    camera-size-index = 2;
                                    camera-width = 640;
                                    camera-height = 480;
                                }
                                save-config()
                            }
                        }
                        Button { 
                            text:  camera-opened? "关闭相机": "打开相机";
                            width: 120px;
                            height: 40px;
                            clicked => {
                                camera-opened = !camera-opened;
                                if(camera-opened){
                                    open-camera()   
                                }
                            }
                        }
                        ComboBox {
                            width: 120px;
                            height: 40px;
                            model: serial-name-list;
                            current-value: "串口:"+serial-name;
                            selected(value) => {
                                if(serial-name != value){
                                    serial-name = value;
                                    save-config();
                                    //关闭串口，等待自动重连
                                    serial-opened = false;
                                }
                            }
                        }
                        ComboBox {
                            width: 140px;
                            height: 40px;
                            model: ["115200"];
                            current-value: "波特率:"+baud-rate;
                        }
                        // Button {
                        //     text: "打开串口";
                        //     enabled: !serial-opened;
                        //     width: 120px;
                        //     height: 40px;
                        //     clicked => {
                        //         serial-opened = !serial-opened;
                        //         if(serial-opened){
                        //             open-serial()
                        //         }
                        //     }
                        // }
                        Button {
                            text: "刷新串口列表";
                            width: 120px;
                            height: 40px;
                            clicked => {
                                list-serial()
                            }
                        }
                    }
                }
            }
    }
}
